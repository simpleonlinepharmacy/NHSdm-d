Procedure for unzipping the XML files

1. Delete any old zip file in C:\dmd_Extract_Tool\XMLToUnzipInHere
2. copy new zip file to C:\dmd_Extract_Tool\XMLToUnzipInHere
3. Now run C:\dmd_Extract_Tool\xml-csv.bat
